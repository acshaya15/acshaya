package com.example.dayy1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dayy1Application {

	public static void main(String[] args) {
		SpringApplication.run(Dayy1Application.class, args);
	}

}
