package com.example.dayy1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dayy1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
